# Secure Enterprise RAG Assistant 📚

An end-to-end Retrieval-Augmented Generation (RAG) application built with Google Gemini 3.6 Flash, ChromaDB, Streamlit, and Python.

## Features

- **Semantic search:** Gemini `gemini-embedding-001` converts document chunks into embeddings for retrieval.
- **PDF upload:** Upload a document directly through the Streamlit interface.
- **Document chunking:** `RecursiveCharacterTextSplitter` divides the PDF into searchable chunks.
- **Vector database:** ChromaDB stores document chunks and their embeddings in memory.
- **Anti-hallucination guardrails:** Gemini answers only from retrieved context and declines unsupported questions.
- **Source citation:** Answers cite relevant chunks, such as `[Chunk 1]`.
- **Deterministic responses:** Gemini uses temperature `0.0`.

## Project Structure

```text
Enterprise_RAG_App/
├── venv/
├── app.py
├── requirements.txt
├── .env
├── .gitignore
└── README.md
```

## Installation

Create and activate a virtual environment on Windows:

```powershell
python -m venv venv
venv\Scripts\activate
```

Install dependencies:

```powershell
pip install -r requirements.txt
```

Create `.env` in the project root and add your Gemini API key:

```text
GEMINI_API_KEY=your_actual_api_key_here
```

Run the application:

```powershell
streamlit run app.py
```

The app opens at <http://localhost:8501>.

## How It Works

```text
PDF -> Text Extraction -> Chunking -> Gemini Embeddings -> ChromaDB
    -> User Question -> Similarity Search -> Top 3 Chunks
    -> Guardrailed Prompt -> Gemini 2.5 Flash -> Answer + Sources
```

## Testing

1. **In-scope question:** Ask something explicitly answered by the PDF. Expected: an answer with a citation such as `[Chunk X]`.
2. **Out-of-scope question:** Ask `Who won the World Cup in 2022?`. Expected: `I cannot answer this based on the provided documents.`
3. **Ambiguous question:** Ask `What is the policy?`. The model should use the retrieved chunks and cite its answer.

## Technologies

- Python
- Streamlit
- Google Gemini
- ChromaDB
- PyPDF
- LangChain Text Splitters
- python-dotenv
