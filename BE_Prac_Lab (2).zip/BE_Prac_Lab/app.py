import os

import chromadb
import streamlit as st
from chromadb.api.types import Documents, EmbeddingFunction, Embeddings
from dotenv import load_dotenv
from google import genai
from google.genai import types
from langchain_text_splitters import RecursiveCharacterTextSplitter
from pypdf import PdfReader

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

if not GEMINI_API_KEY or GEMINI_API_KEY == "your_actual_api_key_here":
    st.error("GEMINI_API_KEY is missing. Add your key to the .env file.")
    st.stop()

client = genai.Client(api_key=GEMINI_API_KEY)


class GeminiEmbeddingFunction(EmbeddingFunction):
    def __call__(self, input: Documents) -> Embeddings:
        response = client.models.embed_content(
            model="gemini-embedding-001",
            contents=input,
        )
        return [embedding.values for embedding in response.embeddings]


st.set_page_config(
    page_title="Enterprise RAG Assistant",
    page_icon="📚",
    layout="wide",
)

st.title("📚 Secure Enterprise Document RAG")
st.markdown("Upload a PDF document and ask questions. The AI will cite its sources.")

if "messages" not in st.session_state:
    st.session_state.messages = []

if "collection" not in st.session_state:
    st.session_state.collection = None

with st.sidebar:
    st.header("📄 Document Ingestion")
    uploaded_file = st.file_uploader("Upload a PDF", type="pdf")

if uploaded_file is not None and st.session_state.collection is None:
    with st.spinner("Parsing and chunking document..."):
        reader = PdfReader(uploaded_file)
        raw_text = "\n".join(page.extract_text() or "" for page in reader.pages)

        splitter = RecursiveCharacterTextSplitter(
            chunk_size=500,
            chunk_overlap=100,
        )
        chunks = splitter.split_text(raw_text)

        if not chunks:
            st.error("The uploaded PDF did not contain extractable text.")
            st.stop()

        chroma_client = chromadb.Client()
        try:
            chroma_client.delete_collection("temp_doc_db")
        except Exception:
            pass

        collection = chroma_client.create_collection(
            name="temp_doc_db",
            embedding_function=GeminiEmbeddingFunction(),
        )

        collection.add(
            documents=chunks,
            ids=[f"chunk_{index}" for index in range(len(chunks))],
            metadatas=[
                {"source": uploaded_file.name, "chunk": index}
                for index in range(len(chunks))
            ],
        )

        st.session_state.collection = collection
        st.success(f"✅ Indexed {len(chunks)} chunks successfully!")

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])
        if "sources" in message:
            with st.expander("View Retrieved Sources"):
                for source in message["sources"]:
                    st.info(source)

if st.session_state.collection is not None:
    prompt = st.chat_input("Ask a question about your document...")

    if prompt:
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)

        results = st.session_state.collection.query(
            query_texts=[prompt],
            n_results=3,
        )
        retrieved_documents = results["documents"][0]
        retrieved_metadatas = results["metadatas"][0]

        context_text = "\n\n".join(
            f"[Chunk {metadata['chunk']}]\n{document}"
            for document, metadata in zip(
                retrieved_documents,
                retrieved_metadatas,
            )
        )
        source_list = [
            f"{metadata['source']} — Chunk {metadata['chunk']}"
            for metadata in retrieved_metadatas
        ]

        system_instruction = """
You are a strict Enterprise Q&A Assistant.

Answer the user's question ONLY using the provided context.

Do NOT use outside knowledge.

If the answer is not contained in the context, explicitly state:

"I cannot answer this based on the provided documents."

Do NOT hallucinate or make up information.

When making claims, cite the relevant chunk number inline,
for example [Chunk 1].
"""
        user_payload = f"""
CONTEXT:

{context_text}

USER QUESTION:

{prompt}
"""

        try:
            response = client.models.generate_content(
                model="gemini-3.6-flash",
                contents=user_payload,
                config=types.GenerateContentConfig(
                    system_instruction=system_instruction,
                    temperature=0.0,
                ),
            )
            final_answer = response.text
        except Exception as error:
            final_answer = f"⚠️ An error occurred while generating the answer: {error}"

        with st.chat_message("assistant"):
            st.markdown(final_answer)
            with st.expander("View Retrieved Sources"):
                for source in source_list:
                    st.info(source)

        st.session_state.messages.append(
            {
                "role": "assistant",
                "content": final_answer,
                "sources": source_list,
            }
        )
